package com.cg.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.cg.capstore.bean.Merchant;
import com.cg.capstore.service.ICapStoreService;

@Controller
public class CapStoreController {

	@Autowired
	ICapStoreService capStoreService;

	@RequestMapping(value = "signup", method = RequestMethod.GET)
	public ModelAndView SignupForCustomer( @ModelAttribute("customer") Merchant merchant) {
		boolean valid=false;

		if (merchant.getPassword().equals(merchant.getConfirmPassword())) {	
			System.out.println("match");
		
			valid = capStoreService.validateMerchant(merchant);
		} else {
			String error="passwords must match";
			System.out.println("do not match");
			return new ModelAndView("CustomerSignup", "error", error);
		}
		if(valid){
		
			return new ModelAndView("homepage");
		}else{
			String unsuccessmessage="account already exists";
			System.out.println(unsuccessmessage);
			return new ModelAndView("CustomerSignup", "successmessage", unsuccessmessage);
		}
		
		}
	

	

}
