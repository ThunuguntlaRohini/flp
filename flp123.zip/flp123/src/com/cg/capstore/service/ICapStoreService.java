package com.cg.capstore.service;

import com.cg.capstore.bean.Merchant;

public interface ICapStoreService {

	
	public boolean validateMerchant(Merchant merchant);
	
}
