package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Merchant;
import com.cg.capstore.dao.ICapStoreDAO;
@Service("capStoreService")
public class CapStoreServiceImpl implements ICapStoreService {

	@Autowired
	ICapStoreDAO dao;


	public boolean validateMerchant(Merchant merchant) {
		
		return dao.validateMerchant(merchant);
	}


	
}
