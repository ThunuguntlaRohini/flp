package com.cg.capstore.ui;


public class Customerclient {


}
