package com.cg.capstore.dao;

import com.cg.capstore.bean.Merchant;

public interface ICapStoreDAO {
	


	
	public boolean validateMerchant(Merchant merchant);
	
}
