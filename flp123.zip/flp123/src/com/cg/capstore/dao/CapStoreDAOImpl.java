package com.cg.capstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.cg.capstore.bean.Merchant;


@Repository("dao")
@Transactional
public class CapStoreDAOImpl implements ICapStoreDAO {
	@PersistenceContext
	EntityManager em;

	public boolean validateMerchant(Merchant merchant) {
		try{
		System.out.println("hiii");
		Query query=em.createQuery("select mobileNumber from Merchant ");
		List<String> phone=query.getResultList();
		for (String string : phone) {
			if(string.equals(merchant.getMobileNumber())){
				return false;
			}else
				em.persist(merchant);
			return true;
		}
	
	}catch(Exception e){
		e.printStackTrace();
		return false;
		
	}
		return false;
		
	}


	
	
}
